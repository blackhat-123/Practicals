<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cylinder Dimensions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            text-align: center;
        }
        form {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px #aaa;
        }
        label, input, button {
            display: block;
            margin: 10px 0;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<h2>Enter Cylinder Dimensions</h2>

<form action="calculate.php" method="POST">
    <label>Radius (in cm):</label>
    <input type="number" name="radius" step="0.01" required>

    <label>Height (in cm):</label>
    <input type="number" name="height" step="0.01" required>

    <button type="submit">Calculate</button>
</form>

</body>
</html>
