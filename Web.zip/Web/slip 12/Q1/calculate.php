<!-- calculate.php -->
<?php
// Function to calculate the area of the cylinder
function calculateArea($radius, $height) {
    return 2 * M_PI * $radius * ($height + $radius);
}

// Function to calculate the volume of the cylinder
function calculateVolume($radius, $height) {
    return M_PI * pow($radius, 2) * $height;
}

// Retrieve the radius and height from the form
$radius = $_POST['radius'];
$height = $_POST['height'];

// Calculate area and volume
$area = calculateArea($radius, $height);
$volume = calculateVolume($radius, $height);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cylinder Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 40px;
        }
        table {
            width: 50%;
            margin: 0 auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background: #f2f2f2;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            text-decoration: none;
            color: white;
            background: #007BFF;
            border-radius: 5px;
        }
        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<h2>Cylinder Dimensions and Results</h2>

<table>
    <tr>
        <th>Radius</th>
        <td><?= $radius ?> cm</td>
    </tr>
    <tr>
        <th>Height</th>
        <td><?= $height ?> cm</td>
    </tr>
    <tr>
        <th>Surface Area</th>
        <td><?= number_format($area, 2) ?> cm²</td>
    </tr>
    <tr>
        <th>Volume</th>
        <td><?= number_format($volume, 2) ?> cm³</td>
    </tr>
</table>

<a href="index.php" class="btn">Go Back</a>

</body>
</html>
