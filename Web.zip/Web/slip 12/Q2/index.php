<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>String Operations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 40px;
        }
        form {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px #aaa;
        }
        label, input, button {
            display: block;
            margin: 10px 0;
        }
        .radio-group {
            text-align: left;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<h2>String Operations Form</h2>

<form action="process.php" method="POST">
    <label>Enter First String:</label>
    <input type="text" name="string1" required>

    <label>Enter Second String:</label>
    <input type="text" name="string2" required>

    <div class="radio-group">
        <label><input type="radio" name="operation" value="compare" required> Compare Strings</label>
        <label><input type="radio" name="operation" value="uppercase"> Convert to Uppercase</label>
        <label><input type="radio" name="operation" value="lowercase"> Convert to Lowercase</label>
    </div>

    <button type="submit">Perform Operation</button>
</form>

</body>
</html>
