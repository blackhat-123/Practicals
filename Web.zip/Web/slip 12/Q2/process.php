<!-- process.php -->
<?php
// Retrieve form data
$string1 = $_POST['string1'];
$string2 = $_POST['string2'];
$operation = $_POST['operation'];

// Perform the selected operation
$result = "";
switch ($operation) {
    case "compare":
        $comparison = strcmp($string1, $string2);
        if ($comparison == 0) {
            $result = "The strings are equal.";
        } elseif ($comparison > 0) {
            $result = "The first string is greater than the second.";
        } else {
            $result = "The first string is smaller than the second.";
        }
        break;

    case "uppercase":
        $result = "Uppercase of String 1: " . strtoupper($string1) . "<br>";
        $result .= "Uppercase of String 2: " . strtoupper($string2);
        break;

    case "lowercase":
        $result = "Lowercase of String 1: " . strtolower($string1) . "<br>";
        $result .= "Lowercase of String 2: " . strtolower($string2);
        break;

    default:
        $result = "Invalid operation selected.";
        break;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>String Operation Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 40px;
        }
        .result-box {
            width: 60%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px #aaa;
            background: #f9f9f9;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            text-decoration: none;
            color: white;
            background: #007BFF;
            border-radius: 5px;
        }
        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<h2>String Operation Result</h2>

<div class="result-box">
    <h3>Operation Performed:</h3>
    <p><?= $result ?></p>
</div>

<a href="index.php" class="btn">Go Back</a>

</body>
</html>
