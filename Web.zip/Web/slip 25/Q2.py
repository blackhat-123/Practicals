import xml.etree.ElementTree as ET

# Create root element
root = ET.Element("Cricket")

# Add multiple player records
players = [
    {"name": "David Warner", "age": "37", "role": "Batsman"},
    {"name": "Pat Cummins", "age": "31", "role": "Bowler"},
    {"name": "Glenn Maxwell", "age": "35", "role": "All-Rounder"}
]

# Adding players under 'Category' with country="Australia"
category = ET.SubElement(root, "Category", country="Australia")

for player in players:
    player_element = ET.SubElement(category, "Player")
    ET.SubElement(player_element, "Name").text = player["name"]
    ET.SubElement(player_element, "Age").text = player["age"]
    ET.SubElement(player_element, "Role").text = player["role"]

# Convert to string and save to XML file
tree = ET.ElementTree(root)
tree.write("cricket.xml", encoding="utf-8", xml_declaration=True)

print("✅ cricket.xml file created successfully!")
