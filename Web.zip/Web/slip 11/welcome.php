<?php
session_start();

if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; text-align: center; padding: 50px; }
        .container { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px #ccc; width: 400px; margin: 0 auto; }
        h1 { color: #28a745; }
        a { display: inline-block; margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; }
        a:hover { background: #0056b3; }
    </style>
</head>
<body>

<div class="container">
    <h1>Welcome!</h1>
    <p>You have successfully logged in.</p>
    <a href="logout.php">Logout</a>
</div>

</body>
</html>
