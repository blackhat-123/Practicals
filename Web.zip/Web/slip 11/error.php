<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Error</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; text-align: center; padding: 50px; }
        .error-box { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px #ccc; width: 400px; margin: 0 auto; }
        h1 { color: red; }
        a { display: inline-block; margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; }
        a:hover { background: #0056b3; }
    </style>
</head>
<body>

<div class="error-box">
    <h1>Error!</h1>
    <p>You have exceeded 3 incorrect login attempts.</p>
    <a href="logout.php">Try Again</a>
</div>

</body>
</html>
