<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Form - Page 1</title>
</head>
<body>
    <h2>Enter Employee Details</h2>
    <form action="earnings.php" method="POST">
        <label>Employee Number:</label><br>
        <input type="text" name="eno" required><br><br>

        <label>Employee Name:</label><br>
        <input type="text" name="ename" required><br><br>

        <label>Address:</label><br>
        <textarea name="address" required></textarea><br><br>

        <button type="submit">Next</button>
    </form>
</body>
</html>
