<!-- display.php -->
<?php
session_start();

// Retrieve data from session and form submission
$eno = $_SESSION['eno'];
$ename = $_SESSION['ename'];
$address = $_SESSION['address'];

$basic = $_POST['basic'];
$da = $_POST['da'];
$hra = $_POST['hra'];

// Calculate total salary
$total = $basic + $da + $hra;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Information - Page 3</title>
    <style>
        table {
            width: 50%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Employee Information</h2>
    <table>
        <tr>
            <th>Employee Number</th>
            <td><?= $eno ?></td>
        </tr>
        <tr>
            <th>Employee Name</th>
            <td><?= $ename ?></td>
        </tr>
        <tr>
            <th>Address</th>
            <td><?= $address ?></td>
        </tr>
        <tr>
            <th>Basic Salary</th>
            <td><?= $basic ?></td>
        </tr>
        <tr>
            <th>DA</th>
            <td><?= $da ?></td>
        </tr>
        <tr>
            <th>HRA</th>
            <td><?= $hra ?></td>
        </tr>
        <tr>
            <th>Total Salary</th>
            <td><strong><?= $total ?></strong></td>
        </tr>
    </table>

    <a href="index.php">Go Back to Page 1</a>
</body>
</html>
