<!-- earnings.php -->
<?php
// Start the session to pass data between pages
session_start();

// Store employee details in session variables
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['eno'] = $_POST['eno'];
    $_SESSION['ename'] = $_POST['ename'];
    $_SESSION['address'] = $_POST['address'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Earnings Form - Page 2</title>
</head>
<body>
    <h2>Enter Earnings Details</h2>
    <form action="display.php" method="POST">
        <label>Basic Salary:</label><br>
        <input type="number" name="basic" required><br><br>

        <label>DA:</label><br>
        <input type="number" name="da" required><br><br>

        <label>HRA:</label><br>
        <input type="number" name="hra" required><br><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>
