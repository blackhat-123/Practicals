<?php
session_start();

// Define correct credentials
$correct_username = "admin";
$correct_password = "password123";

// Check if session is active
if (!isset($_SESSION['attempt'])) {
    $_SESSION['attempt'] = 0;
}

// Get form input
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validate credentials
if ($username === $correct_username && $password === $correct_password) {
    $_SESSION['is_logged_in'] = true;
    $_SESSION['attempt'] = 0;  // Reset attempts on successful login
    header("Location: welcome.php");
    exit();
} else {
    $_SESSION['attempt']++;

    if ($_SESSION['attempt'] >= 3) {
        $_SESSION['error'] = "You have exceeded 3 incorrect login attempts.";
        header("Location: error.php");
        exit();
    } else {
        $_SESSION['error'] = "Incorrect username or password. Attempt {$_SESSION['attempt']} of 3.";
        header("Location: index.php");
        exit();
    }
}
