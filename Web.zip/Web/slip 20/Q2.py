from flask import Flask, request, jsonify
import sqlite3
from bcrypt import hashpw, gensalt

app = Flask(__name__)

# Initialize SQLite Database
def init_db():
    with sqlite3.connect("users.db") as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            full_name TEXT NOT NULL,
                            contact TEXT NOT NULL,
                            email TEXT NOT NULL UNIQUE,
                            password TEXT NOT NULL)''')
        conn.commit()

@app.route('/register', methods=['POST'])
def register():
    """
    Registers a new user with basic details and hashed password.
    """
    data = request.json
    full_name = data.get('full_name')
    contact = data.get('contact')
    email = data.get('email')
    password = data.get('password')
    confirm_password = data.get('confirm_password')

    if not all([full_name, contact, email, password, confirm_password]):
        return jsonify({"error": "All fields are required!"}), 400
    
    if password != confirm_password:
        return jsonify({"error": "Passwords do not match!"}), 400
    
    hashed_password = hashpw(password.encode('utf-8'), gensalt())

    try:
        with sqlite3.connect("users.db") as conn:
            cursor = conn.cursor()
            cursor.execute('''INSERT INTO users (full_name, contact, email, password)
                              VALUES (?, ?, ?, ?)''',
                           (full_name, contact, email, hashed_password))
            conn.commit()
            return jsonify({"message": "User registered successfully!"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Email already exists!"}), 409


@app.route('/users', methods=['GET'])
def get_users():
    """
    Displays all registered users (excluding passwords).
    """
    with sqlite3.connect("users.db") as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT id, full_name, contact, email FROM users')
        users = cursor.fetchall()

    return jsonify(users), 200


if __name__ == '__main__':
    init_db()
    app.run(debug=True)


# curl -X POST http://127.0.0.1:5000/register \
# -H "Content-Type: application/json" \
# -d '{"full_name": "John Doe", "contact": "1234567890", "email": "john@example.com", "password": "pass123", "confirm_password": "pass123"}'

# View All Users:

# bash
# Copy
# Edit
# curl http://127.0.0.1:5000/users