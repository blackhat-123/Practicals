from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory book table
books = {}
book_id_counter = 1  # Counter to generate unique book IDs


# ✅ Add Book
@app.route('/add_book', methods=['POST'])
def add_book():
    """
    Adds a new book with title, author, genre, and price.
    """
    global book_id_counter

    data = request.json
    title = data.get('title')
    author = data.get('author')
    genre = data.get('genre')
    price = data.get('price')

    if not title or not author or not genre or price is None:
        return jsonify({"error": "All book details are required"}), 400

    book_id = book_id_counter
    books[book_id] = {
        "title": title,
        "author": author,
        "genre": genre,
        "price": price
    }
    book_id_counter += 1

    return jsonify({"message": "Book added successfully", "book_id": book_id}), 201


# ✅ Delete Book by ID
@app.route('/delete_book/<int:book_id>', methods=['DELETE'])
def delete_book(book_id):
    """
    Deletes a book by ID.
    """
    if book_id not in books:
        return jsonify({"error": "Book not found"}), 404

    del books[book_id]
    return jsonify({"message": f"Book ID {book_id} deleted"}), 200


# ✅ Update Book by ID
@app.route('/update_book/<int:book_id>', methods=['PUT'])
def update_book(book_id):
    """
    Updates book details by ID.
    """
    if book_id not in books:
        return jsonify({"error": "Book not found"}), 404

    data = request.json
    title = data.get('title')
    author = data.get('author')
    genre = data.get('genre')
    price = data.get('price')

    if title:
        books[book_id]['title'] = title
    if author:
        books[book_id]['author'] = author
    if genre:
        books[book_id]['genre'] = genre
    if price is not None:
        books[book_id]['price'] = price

    return jsonify({"message": f"Book ID {book_id} updated successfully"}), 200


# ✅ Get Book Details (All or by ID)
@app.route('/get_books', methods=['GET'])
def get_books():
    """
    Retrieves all books or a specific book by ID.
    """
    book_id = request.args.get('id')

    if book_id:
        book_id = int(book_id)
        if book_id in books:
            return jsonify(books[book_id]), 200
        else:
            return jsonify({"error": "Book not found"}), 404
    else:
        return jsonify(books), 200


if __name__ == '__main__':
    app.run(debug=True)
