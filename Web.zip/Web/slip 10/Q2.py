import xml.etree.ElementTree as ET

# Create the root element
root = ET.Element("Employees")

# Sample employee data
employees = [
    {"ID": "E101", "Name": "John Doe", "Position": "Software Engineer", "Department": "IT", "DateOfJoining": "2020-05-12"},
    {"ID": "E102", "Name": "Alice Smith", "Position": "Data Analyst", "Department": "Data Science", "DateOfJoining": "2019-03-22"},
    {"ID": "E103", "Name": "Robert Brown", "Position": "Project Manager", "Department": "Operations", "DateOfJoining": "2018-07-15"},
    {"ID": "E104", "Name": "Emily White", "Position": "HR Manager", "Department": "HR", "DateOfJoining": "2021-11-30"},
    {"ID": "E105", "Name": "Michael Johnson", "Position": "Network Engineer", "Department": "Infrastructure", "DateOfJoining": "2022-01-10"}
]

# Create employee elements
for employee in employees:
    emp_element = ET.SubElement(root, "Employee")

    id_element = ET.SubElement(emp_element, "EmployeeID")
    id_element.text = employee["ID"]

    name_element = ET.SubElement(emp_element, "Name")
    name_element.text = employee["Name"]

    position_element = ET.SubElement(emp_element, "Position")
    position_element.text = employee["Position"]

    department_element = ET.SubElement(emp_element, "Department")
    department_element.text = employee["Department"]

    doj_element = ET.SubElement(emp_element, "DateOfJoining")
    doj_element.text = employee["DateOfJoining"]

# Create the XML tree
tree = ET.ElementTree(root)

# Write to an XML file
output_file = "Employees.xml"
tree.write(output_file, encoding="utf-8", xml_declaration=True)

print(f"XML file '{output_file}' generated successfully!")
