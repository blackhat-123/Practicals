import xml.etree.ElementTree as ET

# Create the root element
root = ET.Element("Students")

# Sample student data
students = [
    {"ID": "S001", "Name": "Alice Johnson", "Age": "20", "Gender": "Female", "Program": "Computer Science"},
    {"ID": "S002", "Name": "Bob Smith", "Age": "22", "Gender": "Male", "Program": "Cyber Security"},
    {"ID": "S003", "Name": "Charlie Brown", "Age": "21", "Gender": "Male", "Program": "Data Science"},
    {"ID": "S004", "Name": "Diana Lee", "Age": "23", "Gender": "Female", "Program": "Software Engineering"},
    {"ID": "S005", "Name": "Ethan Clark", "Age": "24", "Gender": "Male", "Program": "Information Technology"}
]

# Create student elements
for student in students:
    student_element = ET.SubElement(root, "Student")

    id_element = ET.SubElement(student_element, "StudentID")
    id_element.text = student["ID"]

    name_element = ET.SubElement(student_element, "Name")
    name_element.text = student["Name"]

    age_element = ET.SubElement(student_element, "Age")
    age_element.text = student["Age"]

    gender_element = ET.SubElement(student_element, "Gender")
    gender_element.text = student["Gender"]

    program_element = ET.SubElement(student_element, "Program")
    program_element.text = student["Program"]

# Create the XML tree
tree = ET.ElementTree(root)

# Write to an XML file
output_file = "Student.xml"
tree.write(output_file, encoding="utf-8", xml_declaration=True)

print(f"XML file '{output_file}' generated successfully!")
