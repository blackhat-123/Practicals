import xml.etree.ElementTree as ET

# Create the root element
root = ET.Element("Subjects")

# Sample records
records = [
    {"SubjectID": "101", "SubjectName": "Cybersecurity Basics", "Class": "B.Sc. CDS", "Semester": "3", "Credits": "4"},
    {"SubjectID": "102", "SubjectName": "Network Security", "Class": "B.Sc. CDS", "Semester": "4", "Credits": "5"},
    {"SubjectID": "103", "SubjectName": "Digital Forensics", "Class": "B.Sc. CDS", "Semester": "5", "Credits": "3"}
]

# Add records to XML
for record in records:
    subject = ET.SubElement(root, "Subject")
    
    ET.SubElement(subject, "SubjectID").text = record["SubjectID"]
    ET.SubElement(subject, "SubjectName").text = record["SubjectName"]
    ET.SubElement(subject, "Class").text = record["Class"]
    ET.SubElement(subject, "Semester").text = record["Semester"]
    ET.SubElement(subject, "Credits").text = record["Credits"]

# Convert the XML tree to a string and write it to a file
tree = ET.ElementTree(root)
xml_filename = "Subject.xml"
tree.write(xml_filename, encoding="utf-8", xml_declaration=True)

print(f"XML file '{xml_filename}' has been created successfully.")
