<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Number to Words</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 40px;
        }
        form {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px #aaa;
        }
        label, input, button {
            display: block;
            margin: 10px 0;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<h2>Number to Words Converter</h2>

<form action="process.php" method="POST">
    <label>Enter a Number:</label>
    <input type="number" name="number" required>
    <button type="submit">Convert to Words</button>
</form>

</body>
</html>
