<!-- process.php -->
<?php
// Retrieve the number from form
$number = $_POST['number'] ?? '';

// Array mapping digits to words
$digit_words = [
    "0" => "Zero", "1" => "One", "2" => "Two", "3" => "Three", "4" => "Four",
    "5" => "Five", "6" => "Six", "7" => "Seven", "8" => "Eight", "9" => "Nine"
];

$result = "";

// Check if input is valid
if ($number !== '') {
    // Split the number into individual digits
    $digits = str_split($number);

    // Convert each digit to its word equivalent
    $words = [];
    foreach ($digits as $digit) {
        $words[] = $digit_words[$digit];
    }

    // Join the words with spaces
    $result = implode(" ", $words);
} else {
    $result = "Invalid input. Please enter a number.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Number in Words</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 40px;
        }
        .result-box {
            width: 60%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px #aaa;
            background: #f9f9f9;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            text-decoration: none;
            color: white;
            background: #007BFF;
            border-radius: 5px;
        }
        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<h2>Number in Words</h2>

<div class="result-box">
    <h3>Result:</h3>
    <p><?= htmlspecialchars($result) ?></p>
</div>

<a href="index.php" class="btn">Go Back</a>

</body>
</html>
