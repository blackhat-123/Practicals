import sqlite3
import bcrypt

# Create SQLite3 Database and Table
def create_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        full_name TEXT NOT NULL,
                        contact_number TEXT NOT NULL,
                        email TEXT NOT NULL,
                        password TEXT NOT NULL)''')
    
    conn.commit()
    conn.close()

# Encrypt password using bcrypt
def encrypt_password(password):
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

# Store user data in the database
def store_user_data(full_name, contact_number, email, password):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    encrypted_password = encrypt_password(password)
    
    cursor.execute('''INSERT INTO users (full_name, contact_number, email, password)
                      VALUES (?, ?, ?, ?)''', 
                   (full_name, contact_number, email, encrypted_password))
    
    conn.commit()
    conn.close()

# Main program
create_db()

print("\n--- Enter User Information ---")
full_name = input("Full Name: ")
contact_number = input("Contact Number: ")
email = input("Email ID: ")
password = input("Password: ")
confirm_password = input("Confirm Password: ")

if password == confirm_password:
    store_user_data(full_name, contact_number, email, password)
    print("\n✅ Data stored successfully with encrypted password!")
else:
    print("\n❌ Passwords do not match. Try again.")
