import xml.etree.ElementTree as ET

# Create initial XML file with Australian Team
def create_initial_xml():
    root = ET.Element("Cricket_Team")

    # Australia Team
    australia = ET.SubElement(root, "Team", Country="Australia")
    
    player1 = ET.SubElement(australia, "Player")
    player1.text = "David Warner"
    
    runs1 = ET.SubElement(australia, "Runs")
    runs1.text = "1500"
    
    wickets1 = ET.SubElement(australia, "Wicket")
    wickets1.text = "5"

    # Save to file
    tree = ET.ElementTree(root)
    tree.write("cricket.xml", encoding="utf-8", xml_declaration=True)
    print("Initial 'cricket.xml' file created successfully!")

# Add India team to the existing XML
def add_india_team():
    # Load the existing XML
    tree = ET.parse("cricket.xml")
    root = tree.getroot()

    # Add India Team
    india = ET.SubElement(root, "Team", Country="India")

    player1 = ET.SubElement(india, "Player")
    player1.text = "Virat Kohli"
    
    runs1 = ET.SubElement(india, "Runs")
    runs1.text = "2000"
    
    wickets1 = ET.SubElement(india, "Wicket")
    wickets1.text = "10"

    player2 = ET.SubElement(india, "Player")
    player2.text = "Jasprit Bumrah"

    runs2 = ET.SubElement(india, "Runs")
    runs2.text = "500"

    wickets2 = ET.SubElement(india, "Wicket")
    wickets2.text = "50"

    # Save the updated XML
    tree.write("cricket.xml", encoding="utf-8", xml_declaration=True)
    print("India team added to 'cricket.xml'!")

# Execute the script
create_initial_xml()
add_india_team()
