<?php
// Function to calculate factorial
function factorial($num) {
    if ($num < 0) {
        return "Factorial is not defined for negative numbers.";
    }
    if ($num === 0 || $num === 1) {
        return 1;
    }
    $fact = 1;
    for ($i = 1; $i <= $num; $i++) {
        $fact *= $i;
    }
    return $fact;
}

// Get the number from the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $number = (int) $_POST['number'];

    // Check if the input is valid
    if (is_numeric($number)) {
        $result = factorial($number);
        echo "<h3>Factorial of $number is: $result</h3>";
    } else {
        echo "<h3>Please enter a valid number.</h3>";
    }
}
?>
