<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        h2 {
            text-align: center;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input, textarea, select, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #28a745;
            color: #fff;
            cursor: pointer;
        }
        button:hover {
            background: #218838;
        }
        .stars {
            font-size: 24px;
            color: gold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Feedback Form</h2>

    <!-- Form -->
    <form method="POST" action="">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <label for="feedback">Feedback Message:</label>
        <textarea name="feedback" id="feedback" rows="4" required></textarea>

        <label for="rating">Rating (1-5 stars):</label>
        <select name="rating" id="rating" required>
            <option value="1">1 Star</option>
            <option value="2">2 Stars</option>
            <option value="3">3 Stars</option>
            <option value="4">4 Stars</option>
            <option value="5">5 Stars</option>
        </select>

        <button type="submit" name="submit">Submit Feedback</button>
    </form>

    <?php
    // Display feedback after form submission
    if (isset($_POST['submit'])) {
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $feedback = htmlspecialchars($_POST['feedback']);
        $rating = intval($_POST['rating']);

        echo "<hr>";
        echo "<h3>Feedback Submitted</h3>";
        echo "<p><strong>Name:</strong> $name</p>";
        echo "<p><strong>Email:</strong> $email</p>";
        echo "<p><strong>Feedback:</strong> $feedback</p>";
        
        // Display dynamic stars
        echo "<p><strong>Rating:</strong> ";
        for ($i = 1; $i <= 5; $i++) {
            echo ($i <= $rating) ? "⭐" : "☆";
        }
        echo "</p>";
    }
    ?>
</div>

</body>
</html>
