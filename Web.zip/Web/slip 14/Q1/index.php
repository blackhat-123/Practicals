<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Order Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            text-align: center;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 0 10px #aaa;
        }
        label, input {
            display: block;
            margin: 10px 0;
            width: 100%;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<h2>Product Order Form</h2>

<form action="calculate.php" method="POST">
    <label>Book (₹150 per unit)</label>
    <input type="number" name="book_qty" placeholder="Enter quantity" min="0" value="0">

    <label>Pen (₹20 per unit)</label>
    <input type="number" name="pen_qty" placeholder="Enter quantity" min="0" value="0">

    <label>Bag (₹500 per unit)</label>
    <input type="number" name="bag_qty" placeholder="Enter quantity" min="0" value="0">

    <button type="submit">Calculate Total</button>
</form>

</body>
</html>
