<!-- calculate.php -->
<?php
// Prices per unit
$prices = [
    "Book" => 150,
    "Pen" => 20,
    "Bag" => 500
];

// Retrieve quantities from form
$book_qty = isset($_POST['book_qty']) ? (int) $_POST['book_qty'] : 0;
$pen_qty = isset($_POST['pen_qty']) ? (int) $_POST['pen_qty'] : 0;
$bag_qty = isset($_POST['bag_qty']) ? (int) $_POST['bag_qty'] : 0;

// Calculate total quantities
$total_qty = $book_qty + $pen_qty + $bag_qty;

// Calculate total cost
$total_cost = ($book_qty * $prices['Book']) +
              ($pen_qty * $prices['Pen']) +
              ($bag_qty * $prices['Bag']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Summary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            text-align: center;
        }
        table {
            width: 60%;
            margin: 0 auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background: #f2f2f2;
        }
        .btn {
            display: inline-block;
            margin: 20px;
            padding: 10px 20px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<h2>Order Summary</h2>

<table>
    <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Unit Price (₹)</th>
        <th>Cost (₹)</th>
    </tr>
    <tr>
        <td>Book</td>
        <td><?= $book_qty ?></td>
        <td><?= $prices['Book'] ?></td>
        <td><?= $book_qty * $prices['Book'] ?></td>
    </tr>
    <tr>
        <td>Pen</td>
        <td><?= $pen_qty ?></td>
        <td><?= $prices['Pen'] ?></td>
        <td><?= $pen_qty * $prices['Pen'] ?></td>
    </tr>
    <tr>
        <td>Bag</td>
        <td><?= $bag_qty ?></td>
        <td><?= $prices['Bag'] ?></td>
        <td><?= $bag_qty * $prices['Bag'] ?></td>
    </tr>
    <tr>
        <th colspan="2">Total Quantity</th>
        <td colspan="2"><?= $total_qty ?></td>
    </tr>
    <tr>
        <th colspan="2">Total Cost</th>
        <td colspan="2">₹<?= $total_cost ?></td>
    </tr>
</table>

<a href="index.php" class="btn">Go Back</a>

</body>
</html>
