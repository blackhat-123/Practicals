import xml.etree.ElementTree as ET

# Create the root element
root = ET.Element("Students")

# List of student records
students = [
    {"id": "S001", "name": "Alice Johnson", "age": "20", "gender": "Female", "program": "Computer Science"},
    {"id": "S002", "name": "Bob Smith", "age": "22", "gender": "Male", "program": "Information Technology"},
    {"id": "S003", "name": "Charlie Brown", "age": "21", "gender": "Male", "program": "Cybersecurity"},
    {"id": "S004", "name": "Diana White", "age": "19", "gender": "Female", "program": "Data Science"},
    {"id": "S005", "name": "Ethan Lee", "age": "23", "gender": "Male", "program": "Artificial Intelligence"}
]

# Create XML records for each student
for student in students:
    student_element = ET.SubElement(root, "Student", ID=student["id"])
    ET.SubElement(student_element, "StudentName").text = student["name"]
    ET.SubElement(student_element, "Age").text = student["age"]
    ET.SubElement(student_element, "Gender").text = student["gender"]
    ET.SubElement(student_element, "Program").text = student["program"]

# Write the XML file
tree = ET.ElementTree(root)
tree.write("Student.xml", encoding="utf-8", xml_declaration=True)

print("✅ Student.xml file created successfully!")
