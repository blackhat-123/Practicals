from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory storage for books
books = {}

# Counter to generate unique book IDs
book_id_counter = 1

@app.route('/add_book', methods=['POST'])
def add_book():
    """
    Adds a new book with title, author, genre, and price.
    """
    global book_id_counter

    data = request.json
    title = data.get('title')
    author = data.get('author')
    genre = data.get('genre')
    price = data.get('price')

    if not (title and author and genre and price):
        return jsonify({"error": "All book details are required"}), 400

    book_id = f"B{book_id_counter}"
    books[book_id] = {
        "title": title,
        "author": author,
        "genre": genre,
        "price": price
    }
    book_id_counter += 1

    return jsonify({"message": f"Book added with ID {book_id}", "book": books[book_id]}), 201

@app.route('/delete_book/<book_id>', methods=['DELETE'])
def delete_book(book_id):
    """
    Deletes a book by ID.
    """
    if book_id not in books:
        return jsonify({"error": "Book not found"}), 404

    del books[book_id]
    return jsonify({"message": f"Book {book_id} deleted successfully"}), 200

@app.route('/update_book/<book_id>', methods=['PUT'])
def update_book(book_id):
    """
    Updates book details.
    """
    if book_id not in books:
        return jsonify({"error": "Book not found"}), 404

    data = request.json
    title = data.get('title')
    author = data.get('author')
    genre = data.get('genre')
    price = data.get('price')

    # Update only the provided fields
    if title:
        books[book_id]['title'] = title
    if author:
        books[book_id]['author'] = author
    if genre:
        books[book_id]['genre'] = genre
    if price:
        books[book_id]['price'] = price

    return jsonify({"message": f"Book {book_id} updated successfully", "book": books[book_id]}), 200

@app.route('/get_books', methods=['GET'])
def get_books():
    """
    Retrieves all books or a specific book by ID.
    """
    book_id = request.args.get('id')

    if book_id:
        if book_id not in books:
            return jsonify({"error": "Book not found"}), 404
        return jsonify(books[book_id]), 200

    return jsonify(books), 200

if __name__ == '__main__':
    app.run(debug=True)

# curl -X POST -H "Content-Type: application/json" \
# -d '{"title": "The Alchemist", "author": "Paulo Coelho", "genre": "Fiction", "price": 12.99}' \
# http://127.0.0.1:5000/add_book
