import xml.etree.ElementTree as ET

# Create the root element
root = ET.Element("Timetable")

# Sample timetable data
timetable = [
    {"Day": "Monday", "ClassName": "Cybersecurity Basics", "Instructor": "John Doe", "TimeSlot": "10:00 AM - 12:00 PM", "Classroom": "101"},
    {"Day": "Wednesday", "ClassName": "Ethical Hacking", "Instructor": "Alice Smith", "TimeSlot": "1:00 PM - 3:00 PM", "Classroom": "202"},
    {"Day": "Friday", "ClassName": "Network Security", "Instructor": "David Johnson", "TimeSlot": "11:00 AM - 1:00 PM", "Classroom": "303"}
]

# Loop through the data and add records to the XML
for record in timetable:
    class_element = ET.SubElement(root, "Class")
    
    day = ET.SubElement(class_element, "Day")
    day.text = record["Day"]
    
    class_name = ET.SubElement(class_element, "ClassName")
    class_name.text = record["ClassName"]
    
    instructor = ET.SubElement(class_element, "Instructor")
    instructor.text = record["Instructor"]
    
    time_slot = ET.SubElement(class_element, "TimeSlot")
    time_slot.text = record["TimeSlot"]
    
    classroom = ET.SubElement(class_element, "Classroom")
    classroom.text = record["Classroom"]

# Create the XML tree and write to a file
tree = ET.ElementTree(root)
tree.write("Timetable.xml", encoding="utf-8", xml_declaration=True)

print("Timetable.xml file created successfully!")
