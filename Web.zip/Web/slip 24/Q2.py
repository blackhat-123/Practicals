import requests

# Replace with your ExchangeRate-API key (Get a free one at: https://www.exchangerate-api.com/)
API_KEY = "YOUR_API_KEY"  
BASE_URL = f"https://v6.exchangerate-api.com/v6/{API_KEY}/latest"

def get_exchange_rate(base_currency, target_currency):
    """
    Get the exchange rate between two currencies.
    """
    try:
        response = requests.get(f"{BASE_URL}/{base_currency}")
        data = response.json()

        # Check if the response is valid
        if response.status_code != 200 or "error" in data:
            print("Error fetching exchange rate:", data.get("error", "Unknown error"))
            return None

        # Retrieve the exchange rate
        rates = data.get("conversion_rates", {})
        if target_currency in rates:
            return rates[target_currency]
        else:
            print("Invalid target currency code.")
            return None

    except Exception as e:
        print("An error occurred:", e)
        return None


def convert_currency(amount, base_currency, target_currency):
    """
    Convert amount from one currency to another.
    """
    rate = get_exchange_rate(base_currency, target_currency)
    if rate:
        converted_amount = amount * rate
        print(f"\n{amount} {base_currency} = {converted_amount:.2f} {target_currency}")
    else:
        print("\nConversion failed. Check currency codes or API status.")


# Main function
def main():
    print("\n💱 Currency Converter Using ExchangeRate-API 💱")

    # Get currency details from the user
    base_currency = input("Enter base currency code (e.g., USD): ").upper()
    target_currency = input("Enter target currency code (e.g., EUR): ").upper()

    # Check exchange rate or perform conversion
    option = input("\nChoose an option:\n1. Display exchange rate\n2. Convert amount\nEnter your choice (1/2): ")

    if option == "1":
        rate = get_exchange_rate(base_currency, target_currency)
        if rate:
            print(f"\nExchange Rate: 1 {base_currency} = {rate:.2f} {target_currency}")
        else:
            print("\nFailed to fetch exchange rate.")
    elif option == "2":
        amount = float(input("Enter the amount to convert: "))
        convert_currency(amount, base_currency, target_currency)
    else:
        print("\nInvalid option. Please choose 1 or 2.")


if __name__ == "__main__":
    main()
