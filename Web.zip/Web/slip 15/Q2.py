import xml.etree.ElementTree as ET

# Define timetable data
timetable_data = [
    {"Day": "Monday", "ClassName": "Network Security", "Instructor": "Prof. John Smith", "TimeSlot": "10:00 AM - 12:00 PM", "Classroom": "Room 101"},
    {"Day": "Wednesday", "ClassName": "Web Development", "Instructor": "Ms. Alice Brown", "TimeSlot": "02:00 PM - 04:00 PM", "Classroom": "Room 205"},
    {"Day": "Friday", "ClassName": "Cyber Forensics", "Instructor": "Dr. Michael Lee", "TimeSlot": "11:00 AM - 01:00 PM", "Classroom": "Lab 303"}
]

# Create the root element
timetable = ET.Element("Timetable")

# Add each class record
for data in timetable_data:
    class_element = ET.SubElement(timetable, "Class")

    # Add sub-elements
    ET.SubElement(class_element, "Day").text = data["Day"]
    ET.SubElement(class_element, "ClassName").text = data["ClassName"]
    ET.SubElement(class_element, "Instructor").text = data["Instructor"]
    ET.SubElement(class_element, "TimeSlot").text = data["TimeSlot"]
    ET.SubElement(class_element, "Classroom").text = data["Classroom"]

# Generate the XML tree
tree = ET.ElementTree(timetable)

# Save the XML file
output_file = "Timetable.xml"
tree.write(output_file, encoding="utf-8", xml_declaration=True)

print(f"{output_file} generated successfully!")
