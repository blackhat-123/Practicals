import re

# Function to validate password
def validate_password(password):
    # Check password length (greater than 8)
    if len(password) <= 8:
        return "Enter complex password (Password should be longer than 8 characters)"

    # Check for alphabets, numbers, and special symbols
    if (re.search(r'[a-zA-Z]', password) and  # Contains alphabets
        re.search(r'[0-9]', password) and      # Contains digits
        re.search(r'[^a-zA-Z0-9]', password)):  # Contains special symbols
        return "You entered a strong password!"
    else:
        return "Enter complex password (Include alphabets, numbers, and special symbols)"

# Accept username and password
username = input("Enter Username: ")
password = input("Enter Password: ")

# Validate the password
result = validate_password(password)
print(result)
