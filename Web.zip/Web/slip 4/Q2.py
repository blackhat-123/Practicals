import re

# Function to validate password
def validate_password(password):
    # Check length
    if len(password) < 8:
        return False
    
    # Check for numbers, alphabets, and special characters
    has_number = bool(re.search(r'\d', password))
    has_alpha = bool(re.search(r'[a-zA-Z]', password))
    has_special = bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))

    # Return True only if all conditions are met
    return has_number and has_alpha and has_special

# Main program
username = input("Enter username: ")
password = input("Enter password: ")

if validate_password(password):
    print("\n✅ You entered a strong password")
else:
    print("\n❌ Enter a complex password")
