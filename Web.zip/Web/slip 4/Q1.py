import requests

# OpenWeatherMap API Key (Replace with your own key)
API_KEY = "YOUR_OPENWEATHERMAP_API_KEY"
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

# Function to get weather data
def get_weather(city):
    # API request URL
    url = f"{BASE_URL}?q={city}&appid={API_KEY}&units=metric"
    
    try:
        response = requests.get(url)
        data = response.json()

        if response.status_code == 200:
            city = data["name"]
            country = data["sys"]["country"]
            temp = data["main"]["temp"]
            feels_like = data["main"]["feels_like"]
            humidity = data["main"]["humidity"]
            weather = data["weather"][0]["description"]

            print("\n🌦️ Weather Information 🌦️")
            print(f"📍 City: {city}, {country}")
            print(f"🌡️ Temperature: {temp}°C (Feels like {feels_like}°C)")
            print(f"💧 Humidity: {humidity}%")
            print(f"🌤️ Condition: {weather.capitalize()}")
        
        else:
            print("❌ City not found or invalid API key!")

    except Exception as e:
        print("⚠️ An error occurred:", e)

# Main program
if __name__ == "__main__":
    city = input("Enter city name: ")
    get_weather(city)
