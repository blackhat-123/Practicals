import xml.etree.ElementTree as ET

# Create the root element
root = ET.Element("CourseRegistrations")

# Sample data for 5 student course registrations
registrations = [
    {"RegID": "R001", "StudentName": "Alice Johnson", "CourseName": "Python Programming", "Instructor": "John Smith", "Date": "2025-04-01"},
    {"RegID": "R002", "StudentName": "Bob Williams", "CourseName": "Data Science", "Instructor": "Emma Brown", "Date": "2025-04-02"},
    {"RegID": "R003", "StudentName": "Charlie Davis", "CourseName": "Web Development", "Instructor": "Olivia Taylor", "Date": "2025-04-03"},
    {"RegID": "R004", "StudentName": "David White", "CourseName": "Cyber Security", "Instructor": "Michael Lee", "Date": "2025-04-04"},
    {"RegID": "R005", "StudentName": "Eve Martin", "CourseName": "Machine Learning", "Instructor": "Sophia Harris", "Date": "2025-04-05"}
]

# Generate XML structure
for reg in registrations:
    record = ET.SubElement(root, "Registration")

    ET.SubElement(record, "RegistrationID").text = reg["RegID"]
    ET.SubElement(record, "StudentName").text = reg["StudentName"]
    ET.SubElement(record, "CourseName").text = reg["CourseName"]
    ET.SubElement(record, "Instructor").text = reg["Instructor"]
    ET.SubElement(record, "DateOfRegistration").text = reg["Date"]

# Create and write to the XML file
tree = ET.ElementTree(root)
xml_file = "Course_Registrations.xml"
tree.write(xml_file, encoding="utf-8", xml_declaration=True)

print(f"XML file '{xml_file}' generated successfully.")
