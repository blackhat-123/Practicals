<?php
// Prices per item
$prices = [
    "books" => 200,
    "pens" => 20,
    "bags" => 500
];

// Retrieve quantities from the form
$books = isset($_POST['books']) ? intval($_POST['books']) : 0;
$pens = isset($_POST['pens']) ? intval($_POST['pens']) : 0;
$bags = isset($_POST['bags']) ? intval($_POST['bags']) : 0;

// Calculate total quantities and costs
$totalQuantity = $books + $pens + $bags;
$totalCost = ($books * $prices['books']) + ($pens * $prices['pens']) + ($bags * $prices['bags']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Summary</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background: #f9f9f9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Product Summary</h2>

    <table>
        <tr>
            <th>Product</th>
            <th>Unit Price (₹)</th>
            <th>Quantity</th>
            <th>Total Price (₹)</th>
        </tr>
        <tr>
            <td>Books</td>
            <td><?= $prices['books'] ?></td>
            <td><?= $books ?></td>
            <td><?= $books * $prices['books'] ?></td>
        </tr>
        <tr>
            <td>Pens</td>
            <td><?= $prices['pens'] ?></td>
            <td><?= $pens ?></td>
            <td><?= $pens * $prices['pens'] ?></td>
        </tr>
        <tr>
            <td>Bags</td>
            <td><?= $prices['bags'] ?></td>
            <td><?= $bags ?></td>
            <td><?= $bags * $prices['bags'] ?></td>
        </tr>
    </table>

    <h3>Total Quantity: <?= $totalQuantity ?></h3>
    <h3>Total Cost: ₹<?= $totalCost ?></h3>

</div>

</body>
</html>
