<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Selection</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background: #f9f9f9;
        }
        label, select, input {
            display: block;
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
        }
        button {
            background: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background: #45a049;
        }
    </style>
</head>
<body>

<h2>Select Products and Enter Quantities</h2>

<form action="process.php" method="POST">
    <label for="books">Books (₹200 each):</label>
    <input type="number" id="books" name="books" min="0" placeholder="Enter quantity">

    <label for="pens">Pens (₹20 each):</label>
    <input type="number" id="pens" name="pens" min="0" placeholder="Enter quantity">

    <label for="bags">Bags (₹500 each):</label>
    <input type="number" id="bags" name="bags" min="0" placeholder="Enter quantity">

    <button type="submit">Calculate</button>
</form>

</body>
</html>
