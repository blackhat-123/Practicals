import xml.etree.ElementTree as ET

# Create the root element
root = ET.Element("BreakfastMenu")

# Add initial food items
items = [
    {"Name": "French Fries", "Price": "Rs45", "Description": "Young youths are very much interested to eat it", "Calories": "650"},
    {"Name": "Sandwich", "Price": "Rs60", "Description": "Crispy and tasty with cheese", "Calories": "550"},
]

for item in items:
    food = ET.SubElement(root, "Food")
    
    ET.SubElement(food, "Name").text = item["Name"]
    ET.SubElement(food, "Price").text = item["Price"]
    ET.SubElement(food, "Description").text = item["Description"]
    ET.SubElement(food, "Calories").text = item["Calories"]

# Create the XML tree and write to the file
tree = ET.ElementTree(root)
xml_file = "breakfast.xml"
tree.write(xml_file, encoding="utf-8", xml_declaration=True)

# --- Add multiple elements in the "Juice" category ---
# Load the existing XML file
tree = ET.parse(xml_file)
root = tree.getroot()

# Add Juice items
juices = [
    {"Name": "Orange Juice", "Price": "Rs30", "Description": "Fresh and healthy", "Calories": "120"},
    {"Name": "Apple Juice", "Price": "Rs35", "Description": "Rich in vitamins", "Calories": "110"},
    {"Name": "Mango Shake", "Price": "Rs50", "Description": "Sweet and creamy", "Calories": "200"}
]

# Add the new elements under the Juice category
for juice in juices:
    juice_item = ET.SubElement(root, "Juice")
    
    ET.SubElement(juice_item, "Name").text = juice["Name"]
    ET.SubElement(juice_item, "Price").text = juice["Price"]
    ET.SubElement(juice_item, "Description").text = juice["Description"]
    ET.SubElement(juice_item, "Calories").text = juice["Calories"]

# Save the updated XML file
tree.write(xml_file, encoding="utf-8", xml_declaration=True)

print(f"XML file '{xml_file}' created and updated with Juice category successfully.")
