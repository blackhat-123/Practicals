from flask import Flask, request, jsonify

app = Flask(__name__)

def is_strong_password(password):
    """
    Checks if the password is strong:
    - At least 8 characters long
    - Contains at least one digit, one letter, and one special character
    """
    if len(password) < 8:
        return False
    
    has_digit = any(char.isdigit() for char in password)
    has_letter = any(char.isalpha() for char in password)
    has_special = any(not char.isalnum() for char in password)
    
    return has_digit and has_letter and has_special

@app.route('/register', methods=['POST'])
def register():
    """
    Accepts username and password, validates the password, and returns appropriate message.
    """
    data = request.json
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    if is_strong_password(password):
        return jsonify({"message": "You entered a strong password"}), 200
    else:
        return jsonify({"error": "Enter a complex password"}), 400

if __name__ == '__main__':
    app.run(debug=True)


