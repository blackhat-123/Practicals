from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample in-memory dairy product price table (acting as a database)
dairy_products = {}

@app.route('/add_product', methods=['POST'])
def add_product():
    """
    Adds a new dairy product with its price.
    """
    data = request.json
    product_name = data.get('name')
    price = data.get('price')

    if not product_name or price is None:
        return jsonify({"error": "Product name and price are required"}), 400
    
    dairy_products[product_name] = price
    return jsonify({"message": f"{product_name} added with price {price}"}), 201

@app.route('/delete_product', methods=['DELETE'])
def delete_product():
    """
    Deletes a dairy product from the price table.
    """
    data = request.json
    product_name = data.get('name')

    if not product_name or product_name not in dairy_products:
        return jsonify({"error": "Product not found"}), 404
    
    del dairy_products[product_name]
    return jsonify({"message": f"{product_name} deleted"}), 200

@app.route('/update_product', methods=['PUT'])
def update_product():
    """
    Updates the price of an existing dairy product.
    """
    data = request.json
    product_name = data.get('name')
    new_price = data.get('price')

    if not product_name or new_price is None:
        return jsonify({"error": "Product name and new price are required"}), 400
    
    if product_name not in dairy_products:
        return jsonify({"error": "Product not found"}), 404
    
    dairy_products[product_name] = new_price
    return jsonify({"message": f"{product_name} price updated to {new_price}"}), 200

if __name__ == '__main__':
    app.run(debug=True)

#curl -X POST http://127.0.0.1:5000/add_product -H "Content-Type: application/json" -d '{"name": "Milk", "price": 3.5}'
#curl -X DELETE http://127.0.0.1:5000/delete_product -H "Content-Type: application/json" -d '{"name": "Milk"}'
#curl -X PUT http://127.0.0.1:5000/update_product -H "Content-Type: application/json" -d '{"name": "Milk", "price": 4.0}'
